import { useEffect, useState } from "react";
import Message from "./components/Message";


export default function App() {

    const [mensagem, setMensagem] = useState("");

    const [chat, setChat] = useState([]);

    const [chats, setChats] = useState([]);

    const [chatAtual, setChatAtual] = useState(null);

    const [pesquisa, setPesquisa] = useState("");

    const [pensando, setPensando] = useState(false);

    useEffect(() => {

        carregarChats();

    }, []);

    async function carregarChats() {

        try {

            const resposta = await fetch(
                "http://localhost:3001/api/chats"
            );

            const dados = await resposta.json();

            setChats(dados);

            if (dados.length > 0) {

                setChatAtual(dados[0].id);

                setChat(dados[0].mensagens);

            }

        } catch (erro) {

            console.error(erro);

        }

    }

    async function novoChat() {

        try {

            const resposta = await fetch(

                "http://localhost:3001/api/chats/novo",

                {

                    method: "POST"

                }

            );

            const novo = await resposta.json();

            setChats([novo, ...chats]);

            setChatAtual(novo.id);

            setChat([]);

            carregarChats();

        } catch (erro) {

            console.error(erro);

        }

    }

    async function excluirChat(id) {

        try {

            await fetch(

                "http://localhost:3001/api/chats/" + id,

                {

                    method: "DELETE"

                }

            );

            carregarChats();

            setChat([]);

        } catch (erro) {

            console.error(erro);

        }

    }

    async function enviar() {

        if (!mensagem.trim()) return;

        const historico = [

            ...chat,

            {

                tipo: "user",

                texto: mensagem

            }

        ];

        setChat(historico);

        const pergunta = mensagem;

        setMensagem("");

        setPensando(true);

        try {

            const resposta = await fetch(

                "http://localhost:3001/api/chat",

                {

                    method: "POST",

                    headers: {

                        "Content-Type": "application/json"

                    },

                    body: JSON.stringify({

                        mensagem: pergunta,

                        chatId: chatAtual

                    })

                }

            );

            const dados = await resposta.json();

            setPensando(false);

            setChat([

                ...historico,

                {

                    tipo: "ia",

                    texto: dados.resposta

                }

            ]);

            carregarChats();

        } catch (erro) {

            console.error(erro);

            setPensando(false);

        }

    }
        return (

        <div className="app">

            <div className="sidebar">

                <h2>DevCoder AI</h2>

                <button onClick={novoChat}>
                    + Novo Chat
                </button>

                <input
                    className="pesquisa"
                    placeholder="Pesquisar..."
                    value={pesquisa}
                    onChange={(e) => setPesquisa(e.target.value)}
                />

                <div className="historico">

                    {

                        chats
                            .filter(chat =>
                                chat.titulo
                                    .toLowerCase()
                                    .includes(
                                        pesquisa.toLowerCase()
                                    )
                            )

                            .map(chat => (

                                <div
                                    key={chat.id}
                                    className={
                                        chatAtual === chat.id
                                            ? "chatItem ativo"
                                            : "chatItem"
                                    }
                                >

                                    <div
                                        className="tituloChat"
                                        onClick={() => {

                                            setChatAtual(chat.id);

                                            setChat(chat.mensagens);

                                        }}
                                    >

                                        {chat.titulo}

                                    </div>

                                    <button
                                        className="btnExcluir"
                                        onClick={() => excluirChat(chat.id)}
                                    >

                                        🗑

                                    </button>

                                </div>

                            ))

                    }

                </div>

            </div>

            <div className="chat">

                <div className="topo">

                    <h1>DevCoder AI</h1>

                </div>

                <div className="mensagens">

                    {

chat.map((msg, index) => (

    <Message
        key={index}
        msg={msg}
    />

))

                    }

                    {

                        pensando && (

                            <div className="ia pensando">

                                <div className="typing">

                                    <span></span>
                                    <span></span>
                                    <span></span>

                                </div>

                                <span className="textoPensando">

                                    Pensando...

                                </span>

                            </div>

                        )

                    }

                </div>
                                <div className="inputArea">

                    <input

                        value={mensagem}

                        onChange={(e) => setMensagem(e.target.value)}

                        placeholder="Digite sua pergunta..."

                        onKeyDown={(e) => {

                            if (e.key === "Enter") {

                                enviar();

                            }

                        }}

                    />

                    <button

                        onClick={enviar}

                        disabled={pensando}

                    >

                        {

                            pensando

                                ? "Pensando..."

                                : "Enviar"

                        }

                    </button>

                </div>

            </div>

        </div>

    );

}
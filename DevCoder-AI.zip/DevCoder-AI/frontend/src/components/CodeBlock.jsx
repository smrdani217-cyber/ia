import { useState } from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";

export default function CodeBlock({ language, code }) {

    const [copiado, setCopiado] = useState(false);

    async function copiarCodigo() {

        try {

            await navigator.clipboard.writeText(code);

            setCopiado(true);

            setTimeout(() => {

                setCopiado(false);

            }, 2000);

        } catch (erro) {

            console.error("Erro ao copiar:", erro);

        }

    }

    return (

        <div
            style={{
                marginTop: "15px",
                marginBottom: "15px",
                borderRadius: "10px",
                overflow: "hidden",
                border: "1px solid #2f2f2f"
            }}
        >

            <div
                style={{
                    background: "#1e1e1e",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 15px"
                }}
            >

                <strong
                    style={{
                        color: "#ffffff",
                        textTransform: "uppercase",
                        fontSize: "13px"
                    }}
                >
                    {language}
                </strong>

                <button
                    onClick={copiarCodigo}
                    style={{
                        background: "#10a37f",
                        color: "#fff",
                        border: "none",
                        padding: "6px 12px",
                        borderRadius: "6px",
                        cursor: "pointer",
                        fontWeight: "bold"
                    }}
                >
                    {copiado ? "Copiado!" : "Copiar"}
                </button>

            </div>

            <SyntaxHighlighter
                language={language}
                style={oneDark}
                customStyle={{
                    margin: 0,
                    fontSize: "14px",
                    borderRadius: 0
                }}
                wrapLongLines={true}
            >
                {code}
            </SyntaxHighlighter>

        </div>

    );

}
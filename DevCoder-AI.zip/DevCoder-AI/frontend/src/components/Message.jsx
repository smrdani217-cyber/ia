import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import CodeBlock from "./CodeBlock";

export default function Message({ msg }) {

    return (

        <div
            className={
                msg.tipo === "ia"
                    ? "ia"
                    : "user"
            }
        >

            {

                msg.tipo === "ia"

                    ?

                    <ReactMarkdown

                        remarkPlugins={[remarkGfm]}

                        components={{

                            code({node, inline, className, children, ...props}) {

                                const match = /language-(\w+)/.exec(className || "");

                                if (!inline && match) {

                                    return (

                                        <CodeBlock

                                            language={match[1]}

                                            code={String(children).replace(/\n$/, "")}

                                        />

                                    );

                                }

                                return (

                                    <code
                                        className={className}
                                        {...props}
                                    >
                                        {children}
                                    </code>

                                );

                            }

                        }}

                    >

                        {msg.texto}

                    </ReactMarkdown>

                    :

                    <span>{msg.texto}</span>

            }

        </div>

    );

}
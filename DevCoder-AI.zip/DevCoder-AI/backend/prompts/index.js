import { SYSTEM_PROMPT } from "./system.js";
import { PROJECT_PROMPT } from "./project.js";
import { DEBUG_PROMPT } from "./debug.js";
import { EXPLAIN_PROMPT } from "./explain.js";
import { REVIEW_PROMPT } from "./review.js";
import { REFACTOR_PROMPT } from "./refactor.js";

export function getPrompt(tipo) {

    switch (tipo) {

        case "project":
            return SYSTEM_PROMPT + "\n\n" + PROJECT_PROMPT;

        case "debug":
            return SYSTEM_PROMPT + "\n\n" + DEBUG_PROMPT;

        case "explain":
            return SYSTEM_PROMPT + "\n\n" + EXPLAIN_PROMPT;

        case "review":
            return SYSTEM_PROMPT + "\n\n" + REVIEW_PROMPT;

        case "refactor":
            return SYSTEM_PROMPT + "\n\n" + REFACTOR_PROMPT;

        default:
            return SYSTEM_PROMPT;

    }

}
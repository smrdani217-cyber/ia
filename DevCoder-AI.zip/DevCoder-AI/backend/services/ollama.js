import { detectTask } from "../utils/detectTask.js";
import { getPrompt } from "../prompts/index.js";

export async function perguntarIA(mensagens) {

    try {

        // Última mensagem do usuário
        const ultimaMensagem = mensagens[mensagens.length - 1]?.content || "";

        // Detecta automaticamente o tipo da solicitação
        const tipo = detectTask(ultimaMensagem);

        console.log("Modo detectado:", tipo);

        // Obtém o prompt especializado
        const prompt = getPrompt(tipo);

        // Monta as mensagens para o Ollama
        const mensagensIA = [
            {
                role: "system",
                content: prompt
            },
            ...mensagens
        ];

        const resposta = await fetch(
            "http://localhost:11434/api/chat",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({

                    model: "qwen2.5-coder:7b",

                    messages: mensagensIA,

                    stream: false,

                    options: {

                        temperature: 0.2,

                        num_ctx: 8192,

                        num_predict: 2048,

                        top_p: 0.95,

                        top_k: 40,

                        repeat_penalty: 1.05

                    }

                })

            }

        );

        if (!resposta.ok) {

            throw new Error(
                "Erro ao comunicar com o Ollama."
            );

        }

        const dados = await resposta.json();

        return dados.message.content;

    } catch (erro) {

        console.error("Erro Ollama:", erro);

        return "Erro ao comunicar com o Ollama.";

    }

}
import express from "express";
import fs from "fs";
import { perguntarIA } from "../services/ollama.js";

const router = express.Router();

const caminho = "./data/chats.json";

function lerChats() {
    return JSON.parse(fs.readFileSync(caminho, "utf8"));
}

function salvarChats(chats) {
    fs.writeFileSync(
        caminho,
        JSON.stringify(chats, null, 4)
    );
}

router.post("/", async (req, res) => {

    try {

        const { mensagem, chatId } = req.body;

        const chats = lerChats();

        const chat = chats.find(c => c.id === chatId);

        if (!chat) {

            return res.status(404).json({
                erro: "Chat não encontrado."
            });

        }

        // salva a pergunta

        chat.mensagens.push({
            tipo: "user",
            texto: mensagem
        });

        // envia somente as últimas mensagens para a IA

        const historicoIA = chat.mensagens
            .slice(-30)
            .map(msg => ({
                role: msg.tipo === "user"
                    ? "user"
                    : "assistant",
                content: msg.texto
            }));

        console.time("OLLAMA");

        const respostaIA = await perguntarIA(historicoIA);

        console.timeEnd("OLLAMA");

        // salva resposta

        chat.mensagens.push({
            tipo: "ia",
            texto: respostaIA
        });

        if (chat.titulo === "Novo Chat") {

            chat.titulo = mensagem.substring(0, 35);

        }

        salvarChats(chats);

        return res.json({
            resposta: respostaIA
        });

    } catch (erro) {

        console.error(erro);

        return res.status(500).json({
            erro: "Erro ao consultar IA."
        });

    }

});

export default router;
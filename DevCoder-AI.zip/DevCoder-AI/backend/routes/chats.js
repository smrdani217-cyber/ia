import express from "express";
import fs from "fs";

const router = express.Router();

const caminho = "./data/chats.json";

function lerChats() {
    return JSON.parse(fs.readFileSync(caminho, "utf8"));
}

function salvarChats(chats) {
    fs.writeFileSync(
        caminho,
        JSON.stringify(chats, null, 4)
    );
}

// Listar chats
router.get("/", (req, res) => {
    res.json(lerChats());
});

// Criar novo chat
router.post("/novo", (req, res) => {

    const chats = lerChats();

    const novo = {
        id: Date.now().toString(),
        titulo: "Novo Chat",
        mensagens: []
    };

    chats.unshift(novo);

    salvarChats(chats);

    res.json(novo);

});

// Excluir chat
router.delete("/:id", (req, res) => {

    const chats = lerChats().filter(
        chat => chat.id !== req.params.id
    );

    salvarChats(chats);

    res.json({
        sucesso: true
    });

});

export default router;
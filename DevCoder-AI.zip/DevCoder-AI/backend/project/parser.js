export function parseProjeto(texto) {

    try {

        // Remove markdown
        texto = texto
            .replace(/```json/g, "")
            .replace(/```/g, "")
            .trim();

        // Procura o primeiro {
        const inicio = texto.indexOf("{");

        // Procura o último }
        const fim = texto.lastIndexOf("}");

        if (inicio === -1 || fim === -1) {
            throw new Error("JSON não encontrado.");
        }

        const json = texto.substring(inicio, fim + 1);

        return JSON.parse(json);

    } catch (erro) {

        console.error("Erro ao interpretar projeto:");

        console.error(erro);

        return null;

    }

}s
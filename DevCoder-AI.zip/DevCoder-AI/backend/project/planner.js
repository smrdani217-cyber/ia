import { parseProjeto } from "./parser.js";
import { perguntarIA } from "../services/ollama.js";

export async function planejarProjeto(descricao) {

    const prompt = `
Você é um arquiteto de software.

Sua função NÃO é gerar código.

Sua função é apenas planejar o projeto.

Retorne SOMENTE JSON.

Formato:

{
    "nome":"Nome do Projeto",
    "tecnologias":[
        "React",
        "Node.js"
    ],
    "pastas":[

    ],
    "arquivos":[

    ]
}

Para o campo "arquivos", informe TODOS os arquivos necessários.

Não explique.

Não escreva texto.

Retorne apenas JSON.
`;

    const resposta = await perguntarIA([
        {
            role: "user",
            content: prompt + "\n\nProjeto:\n" + descricao
        }
    ]);

    return parseProjeto(resposta);

}
import express from "express";
import cors from "cors";

import chatRouter from "./routes/chat.js";
import chatsRouter from "./routes/chats.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/chat", chatRouter);
app.use("/api/chats", chatsRouter);

app.listen(3001, () => {
    console.log("Servidor iniciado na porta 3001");
});
export function detectTask(mensagem) {

    const texto = mensagem.toLowerCase();

    const scores = {
        project: 0,
        debug: 0,
        explain: 0,
        review: 0,
        refactor: 0,
        chat: 0
    };

    // =========================
    // Projeto
    // =========================

    const projeto = [
        "crie",
        "criar",
        "faça",
        "fazer",
        "gere",
        "gerar",
        "desenvolva",
        "construa",
        "site",
        "sistema",
        "dashboard",
        "painel",
        "api",
        "backend",
        "frontend",
        "react",
        "node",
        "express",
        "html",
        "css",
        "javascript",
        "typescript",
        "vite",
        "app",
        "projeto",
        "erp",
        "crm"
    ];

    // =========================
    // Debug
    // =========================

    const debug = [
        "erro",
        "bug",
        "referenceerror",
        "typeerror",
        "syntaxerror",
        "cannot",
        "undefined",
        "unexpected",
        "stack",
        "trace",
        "404",
        "500",
        "cors",
        "npm",
        "vite",
        "crash",
        "exception"
    ];

    // =========================
    // Explain
    // =========================

    const explain = [
        "explique",
        "como funciona",
        "o que é",
        "ensine",
        "aprenda",
        "qual a diferença",
        "para que serve"
    ];

    // =========================
    // Review
    // =========================

    const review = [
        "analise",
        "revise",
        "avaliar",
        "opinião",
        "review"
    ];

    // =========================
    // Refactor
    // =========================

    const refactor = [
        "refatore",
        "refatorar",
        "otimize",
        "organize",
        "clean code",
        "melhore"
    ];

    projeto.forEach(p => {
        if (texto.includes(p))
            scores.project++;
    });

    debug.forEach(p => {
        if (texto.includes(p))
            scores.debug++;
    });

    explain.forEach(p => {
        if (texto.includes(p))
            scores.explain++;
    });

    review.forEach(p => {
        if (texto.includes(p))
            scores.review++;
    });

    refactor.forEach(p => {
        if (texto.includes(p))
            scores.refactor++;
    });

    const melhor = Object.entries(scores)
        .sort((a, b) => b[1] - a[1])[0];

    if (melhor[1] === 0)
        return "chat";

    return melhor[0];

}